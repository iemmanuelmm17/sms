# AI Build Prompt: Real-Time SMS/MMS Messaging Web App

> Copy everything below the line into any AI coding assistant to regenerate or extend this app.

---

## Prompt

You are building a full-stack, web-based SMS/MMS messaging platform. Follow the stack, structure, and feature specs below exactly. Ask clarifying questions only if something is structurally ambiguous; otherwise make reasonable, documented assumptions and proceed.

### Tech Stack

- **Backend / API:** PHP 8.2+, Laravel 11
- **Frontend UI:** React 18 (Vite), JavaScript (JSX)
- **Styling:** Tailwind CSS 3
- **SMS/MMS provider:** Dynalink NS-API v2 (Inteliquent carrier underneath; all sends go through the Dynalink API, never directly to the carrier)
- **Realtime:** Laravel Reverb WebSockets + Laravel Echo on the client (Pusher protocol). No polling for inbound messages.

### Dynalink NS-API v2 reference (exact contracts to wrap)

- Auth host: `https://nms1.nyc.birns.net/ns-api/v2`; Core host: `https://core2-nyc.dynalink.net/ns-api/v2`
- `POST /tokens` — password grant `{grant_type:"password", client_id, client_secret, username:"user@domain", password}` → `{access_token, refresh_token, expires_in:3600, user, domain, displayName, ...}`; refresh grant with `{grant_type:"refresh_token", client_id, client_secret, refresh_token}`. **Use sessions**: keep tokens server-side in the Laravel session.
- `GET /domains/{domain}/users/{user}/messagesessions` → inbox list (`messagesession-id`, `messagesession-remote`, `messagesession-sms-number`, `messagesession-last-datetime`, `messagesession-last-message`, `messagesession-last-sender`, `messagesession-last-status: unread|read`, `messagesession-last-type`, `messagesession-last-media-type/size`).
- `GET .../messagesessions/{id}/messages` → thread (`id, timestamp, type:sms|mms, direction:orig|term, dialed, text, status, from-number, messagesession-id, media-type, media-size, file-access-url?`).
- `POST .../messagesessions/{id}/messages` with `{type, message, from-number, destination[]}` — session id must be ≥32 chars `[A-Za-z0-9_]`.
- `POST .../users/{user}/messages` with `{type:"sms", message, destination, from-number}` — new message, API generates session, returns `messagesession-id`.
- MMS: same endpoints + `{data: base64, mime-type: image/png|jpg|gif..., size}`.
- `GET .../users/{user}/smsnumbers` → sender numbers (`number, carrier, mms-capable, group-mms-capable`).
- Contacts: `GET .../contacts?includeDomain=true`; `POST .../contacts {name-first-name, name-middle-name, name-last-name, email, company, phonenumber-work/cell/home/fax}` (**at least one phone required**); `PUT/DELETE .../contacts/{unique-id}`.
- Event subscriptions: `POST /subscriptions {model:"message"|"messagesession", post-url, subscription-geo-support:"no", subscription-expires-datetime:"YYYY-MM-DD HH:MM:SS", user, domain}` → `{id, status:"pending", ...}`; `GET/PUT /subscriptions/{id}`. Renew expiry whenever the session token is refreshed. `message` = 1 event per received message (scope with user+domain); `messagesession` = 1 event per session update (new msg / read mark).

### Architecture Overview

- Laravel serves JSON API (`/api/*`, session auth via `web` middleware) + broadcast auth (`/broadcasting/auth`, Reverb).
- React SPA consumes the API and subscribes to `private-sms.{domain}.{user}` for event `sms.incoming`.
- Incoming SMS/MMS hits `POST /api/webhooks/dynalink` (CSRF-exempt, no session auth — server-to-server), which broadcasts `IncomingSmsReceived` (`ShouldBroadcastNow`) so the UI updates instantly: sidebar row (unread highlight, preview, bubble-to-top) + open conversation append, with zero refresh.
- Outbound/scheduled sends go through queued jobs, **one message per recipient individually** (never a single blast), staggered ~2s, with per-recipient delivery log.

### Backend files to produce

- `app/Services/DynalinkService.php` — typed client for every endpoint above.
- `app/Http/Controllers/AuthController.php` — login/logout/me/refresh; on login + refresh ensure webhook subscriptions exist/renewed.
- `MessageSessionController` (`GET /api/sessions`, `GET /api/sessions/{id}/messages`, `POST ...` reply), `MessageController` (`POST /api/messages` new, `POST /api/messages/bulk` 1-by-1 loop), `ContactController` (CRUD + `GET /template` CSV download + `POST /import` multipart CSV: case-insensitive headers + aliases, row-level `{row, error}` feedback), `SmsNumberController`, `SubscriptionController` (ensure/renew both models, cache ids), `GroupController` (**JSON files**: `storage/app/groups/{domain}/{id}.json`, folder per domain; members are contact snapshots with resolved `phone`), `TemplateController` (CRUD + `POST /{id}/resolve` for `{{placeholders}}`), `ScheduledMessageController` (`targets: {contacts[], group_ids[], company?}` → expanded recipient snapshot → **one delayed `SendScheduledMessage` job per recipient**; edit/cancel pending), `WebhookController` (normalize single/array payloads → broadcast per user channel).
- `app/Events/IncomingSmsReceived.php`, `app/Jobs/SendScheduledMessage.php` (skips cancelled, honors reschedule, logs per-recipient, marks pending→sending→sent|partial), `app/Models/{Template,ScheduledMessage}.php`, migrations, `routes/api.php`, `routes/channels.php` (`sms.{domain}.{user}` authorized against session), `.env.example`, `composer.json`.

### Frontend (React + Vite + Tailwind)

- `src/api/client.js` — axios client + **DEMO_MODE** (when `VITE_API_URL` is empty: localStorage-backed mock data mirroring Dynalink shapes) + helpers (`fmtPhone, initials, avatarColor, fmtTime, primaryPhone`); `src/api/mockData.js`.
- `src/context/AuthContext.jsx`, `src/context/SocketContext.jsx` (Echo+Reverb live; demo `simulateInbound` injector).
- `src/components/Layout.jsx` — icon rail (Messages, Scheduler, Contacts, Groups, Templates, Settings) + header with demo badge, realtime dot, user, logout.
- `src/pages/Login.jsx` — username (`user@domain`) + password; demo accepts any password.
- `src/pages/Messages.jsx` — side panel: **New Message** button + search icon toggle; rows with **initials circle (gray circle if unknown contact)**, name, last-message preview + time, **unread highlight**; conversation window: header (**in-conversation search left**, sender info, from-number picker, **X close**), history (**left = received, right = sent**), compose textarea + row (**Insert Template** picker with placeholder resolution, **Attach File** → base64 MMS, **Emoji** picker, **Send**); `NewMessageModal` (from/to/message + contact picker); realtime effect applies `sms.incoming` instantly (update row, append if open, create session if new).
- `src/pages/Scheduler.jsx` — scheduled list (status badges, per-recipient progress, cancel/delete) + form (name, datetime, from, message, contacts multi-select, groups multi-select, company select).
- `src/pages/Contacts.jsx` — search + **Add**, **Upload CSV**, **Download CSV template**; rows (initials, name, company/phone subtext); detail pane + **Update** modal (one phone required); import summary/errors.
- `src/pages/Groups.jsx` — create/edit from contact multi-select; member list; JSON-per-domain note.
- `src/pages/Templates.jsx` — CRUD with `{{first_name}} {{last_name}} {{company}}` placeholders.
- `src/pages/Settings.jsx` — account, sender numbers + default, notification prefs, connection status.

### Non-functional requirements

- 1-by-1 send semantics everywhere; no bulk single-call to multiple numbers.
- Instant WebSocket updates; unread state; initials/gray-circle avatars — never polling fallbacks.
- CSV robust to header case; group JSON per-domain folders; MMS via base64 + mime-type + size.
- Frontend must run standalone in demo mode (`npm install && npm run dev`) and switch to live via `VITE_API_URL` + `VITE_REVERB_*` env.

*Deliverable: working Laravel API + React/Tailwind SPA matching the above, with WebSocket-driven realtime inbound SMS.*
