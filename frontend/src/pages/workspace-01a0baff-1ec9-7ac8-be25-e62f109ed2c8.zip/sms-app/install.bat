@echo off
setlocal
rem ============================================================
rem  SMS App - Windows installer
rem  Run from the copied project folder (double-click).
rem  Checks prerequisites, asks for the public hostname/IP,
rem  writes both .env files, installs deps, migrates the DB,
rem  and creates start-all.bat.
rem ============================================================
cd /d "%~dp0"
set ROOT=%~dp0
echo === SMS App installer ===
echo Project: %ROOT%
echo.

rem ---------- 0. Sanity: backend + frontend present ----------
if not exist "%ROOT%backend\composer.json" (echo [FAIL] backend\composer.json not found. Copy the WHOLE project folder first. & pause & exit /b 1)
if not exist "%ROOT%frontend\package.json" (echo [FAIL] frontend\package.json not found. Copy the WHOLE project folder first. & pause & exit /b 1)

rem ---------- 1. Prerequisites ----------
where php >nul 2>nul || (echo [FAIL] php not found. Install XAMPP with PHP 8.2+ and add C:\xampp\php to PATH. & pause & exit /b 1)
for /f %%v in ('php -r "echo PHP_VERSION;"') do set PHPV=%%v
for /f "tokens=1,2 delims=." %%a in ("%PHPV%") do (set PHPA=%%a& set PHPB=%%b)
if %PHPA% LSS 8 (echo [FAIL] PHP %PHPV% too old - need 8.2+. & pause & exit /b 1)
if %PHPA% EQU 8 if %PHPB% LSS 2 (echo [FAIL] PHP %PHPV% too old - need 8.2+. & pause & exit /b 1)
echo [ok] PHP %PHPV%
php -m | findstr /I /X "pdo_sqlite" >nul || (call :diagphp pdo_sqlite & pause & exit /b 1)
php -m | findstr /I /X "mbstring" >nul || (call :diagphp mbstring & pause & exit /b 1)
echo [ok] PHP extensions

where composer >nul 2>nul || (echo [FAIL] composer not found. Install from getcomposer.org. & pause & exit /b 1)
echo [ok] composer

where node >nul 2>nul || (echo [FAIL] node not found. Install Node.js 20 LTS from nodejs.org. & pause & exit /b 1)
for /f %%v in ('node -p "process.versions.node"') do set NODEV=%%v
for /f "tokens=1 delims=." %%a in ("%NODEV%") do set NODEA=%%a
if %NODEA% LSS 18 (echo [FAIL] Node %NODEV% too old - need 18+. & pause & exit /b 1)
echo [ok] Node %NODEV%
echo.

rem ---------- 2. Ask for the hostname/IP browsers will use ----------
echo Your IPv4 addresses on this machine:
ipconfig | findstr /I "IPv4"
echo For LAN use, enter the PRIVATE one (192.168.x.x). Public IP/DNS only if port-forwarded.
:askhost
set "H="
set /p "H=Public hostname or IP (e.g. 192.168.18.5 or sms.example.com): "
if "%H%"=="" (echo Please enter something. & goto askhost)
set H=%H:http://=%
set H=%H:https://=%
set H=%H: =%
set "H=%H:&=%"
set "H=%H:|=%"
for /f "tokens=1 delims=/" %%a in ("%H%") do set H=%%a
if "%H%"=="" (echo Could not parse that - try again. & goto askhost)
echo Using host: %H%
echo NOTE: this stack serves plain http. https needs a reverse proxy in front.
echo.

rem ---------- 3. Dependencies ----------
echo --- composer install ---
cd /d "%ROOT%backend"
call composer install || (echo [FAIL] composer install failed. & pause & exit /b 1)
echo --- npm install ---
cd /d "%ROOT%frontend"
call npm install || (echo [FAIL] npm install failed. & pause & exit /b 1)
echo.

rem ---------- 4. Backend .env ----------
if not exist "%ROOT%backend\.env" (
  if not exist "%ROOT%backend\.env.example" (echo [FAIL] backend\.env and backend\.env.example are both missing. & pause & exit /b 1)
  echo Creating backend\.env from example...
  copy "%ROOT%backend\.env.example" "%ROOT%backend\.env" >nul
) else (
  echo Keeping existing backend\.env (APP_KEY preserved^).
)
>>"%ROOT%backend\.env" echo.
call :upsert "%ROOT%backend\.env" "APP_URL" "http://%H%:8000"
findstr /R /C:"^REVERB_APP_KEY=.*." "%ROOT%backend\.env" >nul || for /f %%r in ('php -r "echo bin2hex(random_bytes(16));"') do call :upsert "%ROOT%backend\.env" "REVERB_APP_KEY" "%%r"
findstr /R /C:"^REVERB_APP_SECRET=.*." "%ROOT%backend\.env" >nul || for /f %%r in ('php -r "echo bin2hex(random_bytes(16));"') do call :upsert "%ROOT%backend\.env" "REVERB_APP_SECRET" "%%r"
echo backend .env updated
findstr /R /C:"^APP_URL=http://%H%:8000" "%ROOT%backend\.env" >nul || (echo [FAIL] backend .env update failed. & pause & exit /b 1)
findstr /R /C:"^APP_KEY=base64" "%ROOT%backend\.env" >nul || (
  echo Generating APP_KEY...
  cd /d "%ROOT%backend"
  php artisan key:generate || (echo [FAIL] key:generate failed. & pause & exit /b 1)
)
echo.

rem ---------- 5. Frontend .env ----------
if not exist "%ROOT%frontend\.env" (
  echo Creating frontend\.env from example...
  copy "%ROOT%frontend\.env.example" "%ROOT%frontend\.env" >nul
) else (
  echo Keeping existing frontend\.env (updating host keys^).
)
>>"%ROOT%frontend\.env" echo.
set RKEY=
for /f "tokens=1* delims==" %%a in ('findstr /R /C:"^REVERB_APP_KEY=" "%ROOT%backend\.env"') do set RKEY=%%b
if "%RKEY%"=="" (echo [FAIL] backend REVERB_APP_KEY is empty - backend .env step failed. & pause & exit /b 1)
call :upsert "%ROOT%frontend\.env" "VITE_API_URL" "/"
call :upsert "%ROOT%frontend\.env" "VITE_API_PROXY" "http://localhost:8000"
call :upsert "%ROOT%frontend\.env" "VITE_ALLOWED_HOSTS" "%H%"
call :upsert "%ROOT%frontend\.env" "VITE_REVERB_APP_KEY" "%RKEY%"
call :upsert "%ROOT%frontend\.env" "VITE_REVERB_HOST" "%H%"
call :upsert "%ROOT%frontend\.env" "VITE_REVERB_PORT" "8080"
call :upsert "%ROOT%frontend\.env" "VITE_REVERB_SCHEME" "http"
echo frontend .env updated
findstr /R /C:"^VITE_REVERB_HOST=%H%" "%ROOT%frontend\.env" >nul || (echo [FAIL] frontend .env update failed. & pause & exit /b 1)
findstr /C:"VITE_ALLOWED_HOSTS" "%ROOT%frontend\vite.config.js" >nul || (
  echo [WARN] frontend\vite.config.js does not support VITE_ALLOWED_HOSTS.
  echo        Copy the workspace vite.config.js or LAN browsers get "Blocked request".
)
echo.

rem ---------- 6. Database ----------
cd /d "%ROOT%backend"
if not exist "database\database.sqlite" (
  echo Fresh database - creating + migrating...
  type nul > "database\database.sqlite"
) else (
  echo Existing database.sqlite found - keeping data, running migrations...
)
php artisan migrate || (echo [FAIL] migrate failed. & pause & exit /b 1)
php artisan optimize:clear >nul
echo.

rem ---------- 7. Superadmin account (optional) ----------
set /p "MAKESA=Create a superadmin account now? (y/n): "
if /i "%MAKESA%"=="y" php artisan superadmin:create
echo.

rem ---------- 8. Superadmin LAN access (optional) ----------
echo Your IPv4 addresses - use the LAN one, replace the last octet with 0/24:
ipconfig | findstr /I "IPv4"
set /p "LANCIDR=Allow a LAN subnet into the super portal, e.g. 192.168.18.0/24 (blank = skip): "
set LANCIDR=%LANCIDR: =%
if not "%LANCIDR%"=="" php artisan superadmin:ip --add=%LANCIDR% --label=LAN
echo.

rem ---------- 9. Firewall (optional, needs Admin) ----------
set /p "FW=Add Windows Firewall rules for ports 5173/8000/8080? (y/n): "
if /i "%FW%"=="y" (
  netsh advfirewall firewall add rule name="SMS App 5173" dir=in action=allow protocol=TCP localport=5173 profile=private >nul && echo [ok] 5173 || echo [!!] 5173 rule failed - re-run installer as Admin.
  netsh advfirewall firewall add rule name="SMS App 8000" dir=in action=allow protocol=TCP localport=8000 profile=private >nul && echo [ok] 8000 || echo [!!] 8000 rule failed - re-run installer as Admin.
  netsh advfirewall firewall add rule name="SMS App 8080" dir=in action=allow protocol=TCP localport=8080 profile=private >nul && echo [ok] 8080 || echo [!!] 8080 rule failed - re-run installer as Admin.
)
echo.

rem ---------- 10. start-all.bat ----------
(
echo @echo off
echo cd /d %ROOT%backend
echo start "SMS Backend :8000" php artisan serve --host=0.0.0.0 --port=8000
echo start "SMS Sockets :8080" php artisan reverb:start --host=0.0.0.0 --port=8080
echo start "SMS Queue" php artisan queue:work --tries=3 --timeout=120
echo cd /d %ROOT%frontend
echo start "SMS Frontend :5173" cmd /k npm run dev
echo echo All services starting in separate windows. Close a window to stop it.
) > "%ROOT%start-all.bat"
echo Created start-all.bat
echo.
echo ============================================================
echo  DONE. Next steps:
echo  1. Double-click start-all.bat (4 windows open)
echo  2. Open http://%H%:5173 from any machine on the network
echo  3. Sign in at /super/login, create tenants, verify realtime
echo  Full verify list: DEPLOYMENT.md section 2.5
echo ============================================================
pause
exit /b 0

:upsert
rem args: %1=file  %2=KEY  %3=value (caller quotes all three)
findstr /V /R /C:"^%~2=" "%~1" > "%~1.tmp"
if errorlevel 2 (echo [FAIL] cannot read %~1 & pause & exit 1)
move /Y "%~1.tmp" "%~1" >nul || (echo [FAIL] cannot write %~1 - read-only or locked? & pause & exit 1)
>> "%~1" echo %~2=%~3
exit /b 0

:diagphp
echo [FAIL] PHP is missing %~1 even though you enabled it. Diagnosing...
echo --- Which php.exe is actually used (first line wins) ---
where php
echo --- Which php.ini it loads ---
php --ini | findstr /I "Loaded Configuration File"
echo.
echo Fix: remove the leading ; from extension=%~1 in THAT php.ini file.
echo - If it says (none): php.ini is missing or renamed in the php folder.
echo - If it is NOT C:\xampp\php\php.ini: you edited the wrong file,
echo   or PATH points at a different PHP - put C:\xampp\php first in PATH.
echo - Open the right file via XAMPP Control Panel - Config - PHP (php.ini).
echo - Never edit php.ini-development, it is only a template.
echo - No restart needed for the command line, just re-run install.bat.
exit /b 0
