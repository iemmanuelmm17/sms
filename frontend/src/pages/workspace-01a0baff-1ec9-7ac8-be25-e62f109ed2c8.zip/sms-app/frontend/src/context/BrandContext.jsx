import { createContext, useContext, useEffect, useState } from 'react';
import { api } from '../api/client';

const DEFAULTS = { appName: 'SMS Messaging', logoUrl: null };
const LS = 'sms-brand-v1';

const BrandCtx = createContext({ ...DEFAULTS, loading: true, refresh: async () => {} });
export const useBrand = () => useContext(BrandCtx);

function cached() {
  try { return JSON.parse(localStorage.getItem(LS) || 'null'); } catch { return null; }
}

/** Product branding, fetched once (public endpoint — works pre-login). */
export function BrandProvider({ children }) {
  const [brand, setBrand] = useState(() => cached() || DEFAULTS);
  const [loading, setLoading] = useState(true);

  const refresh = async () => {
    try {
      const b = await api.branding();
      const next = { appName: b?.app_name || DEFAULTS.appName, logoUrl: b?.logo_url || null };
      setBrand(next);
      try { localStorage.setItem(LS, JSON.stringify(next)); } catch {}
    } catch {}
    finally { setLoading(false); }
  };

  useEffect(() => { refresh(); }, []);
  useEffect(() => {
    try { document.title = `${brand.appName} — Messaging`; } catch {}
  }, [brand.appName]);

  return <BrandCtx.Provider value={{ ...brand, loading, refresh }}>{children}</BrandCtx.Provider>;
}
