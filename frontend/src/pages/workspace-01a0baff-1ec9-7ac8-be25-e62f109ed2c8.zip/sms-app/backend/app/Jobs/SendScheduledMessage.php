<?php
// ===========================================================================
// ⚠️  THIS FILE WAS TRUNCATED BY MISTAKE — IT IS NOT REAL CODE. DO NOT DEPLOY.
// ===========================================================================
//
// While adding the "send to opt-in numbers only" flag, a bad line in my edit
// script emptied this file (opened it for writing before reading it). There is
// no backup in this workspace, and I will not guess at a file that sends real
// SMS to real customers.
//
// HOW TO FIX (pick one):
//   1. Copy the file from your machine into the workspace:
//        backend/app/Jobs/SendScheduledMessage.php
//      …then I'll re-apply the two edits below and verify them.
//   2. Paste the contents into chat and I'll restore it here.
//
// Until then, scheduled sends are BROKEN — this class is dispatched once per
// recipient by ScheduledMessageController::store(). Do not restart the queue
// worker or run migrations against a deployment that contains this file.
//
// THE TWO EDITS THAT STILL NEED TO BE APPLIED once the original is back:
//
//   a) Keep the existing opt-out skip, and add the opt-in gate right before it
//      (inside handle(), after the idempotency/overlap guard):
//
//        // "Send to opt-in numbers": only recipients whose latest TCPA action
//        // was an opt-in (START) get the message. Off by default.
//        if (!empty($m->optin_only)) {
//            $in = $optouts->optedInDigits($m->domain, [(string) ($recipient['phone'] ?? '')]);
//            if ($in === []) {
//                $this->logResult($m, $recipient, false, 'skipped: not opted in (send-to-opt-in is on)');
//                \Illuminate\Support\Facades\Cache::forget($idemKey);
//                return;
//            }
//        }
//
//   b) The bulk TCPA wrap condition becomes:
//
//        if (count($m->recipients ?? []) >= 5 && $m->tcpa_script !== false) {
//
// Supporting code (all present and verified):
//   • OptOutService::optedInDigits() / isOptedIn()      — latest-event lookup
//   • ScheduledMessage: optin_only + tcpa_script (fillable/casts)
//   • ScheduledMessageController: validation, persistence, report bucket 'optin'
//   • migrations 000038 (/tcpa_script) and 000039 (/optin_only)
//   • frontend/src/pages/Scheduler.jsx — both checkboxes wired
// ===========================================================================
