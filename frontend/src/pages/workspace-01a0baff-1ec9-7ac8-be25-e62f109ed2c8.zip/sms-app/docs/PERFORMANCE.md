# Performance notes (5/2/6/3 batch, 2026-09-17)

## N+1 audit (5) — result: already clean

Every listing endpoint is a single query (+ in-memory maps) or pure aggregates.
`assignedNumbers()` is in-memory, `SentMessageLog::tenantIdFor()` is cached.
The only per-row costs were **file reads**, fixed with memos (below) — no query
N+1s existed to remove.

**Local step (one line, in `AppServiceProvider::boot()`):**

```php
use Illuminate\Database\Eloquent\Model;
Model::preventLazyLoading(!app()->isProduction());
```

This makes future N+1 regressions throw in dev instead of silently slowing down.
(Couldn't ship from here — `app/Providers/` isn't in the workspace copy.)

## Server + API-response caches (2/3)

| What | Store | TTL | Bust on |
|---|---|---|---|
| Company settings file | static memo + `Cache` | 120s | `set`, `setNumberShared`, `setNumberEmail` |
| Opt-out list | static memo **only** | request | `save()` — STOP/START must bite immediately, so no cross-request cache |
| Reports (summary/trend/byAgent/byNumber/detail/tenants) | `Cache`, key = scope + query string | 300s | TTL only — reports may lag sends 5 min |
| Agent index + directory | `Cache`, versioned key | 120s | any agent write + tenant-admin store/update/delete |
| Templates index | `Cache`, versioned key (per-domain: shared rows leak across users) | 120s | template store/update/destroy |
| Dynalink numbers | `Cache` | 300s | TTL only — provisioning happens outside the app |
| Dynalink contacts | `Cache` | 120s | contact create/update/delete (in the service) |

Deliberately **not** cached: `sessionMessages` (thread freshness; too many
mutation paths to bust reliably), ETag/304 (marginal after the above).

## Lazy loading (6)

- Thread bubbles: newest 100 + "load earlier" (unbounded threads rendered fully before).
- Session list: 150 rows + "show more" (search still covers the full list).
- Contacts list: 100 rows + "show more".
- Skipped: component-level `React.lazy` (no heavy deps to split — Axios/Echo/Pusher
  are light), `<img loading="lazy">` (no `<img>` tags; attachments are links).

## File locking (2026-09-18)

All JSON stores (company settings, opt-outs, companies, groups) go through
`JsonFileStore`: shared-lock reads, exclusive-lock read-modify-write, locked
deletes. Local-disk fast path; non-local disks fall back to plain Storage ops.
Rule: never call back into the store for the same file inside a `mutate()`
closure (flock re-entry deadlocks).

## Next rungs (not done)

Redis (session/cache/queue) when going multi-node; report rollups if a view
demonstrably hurts; virtualized (not just windowed) lists past ~1k rows.
