# Tenant API v1 + Outbound Webhooks

Send SMS/MMS programmatically and receive event callbacks in your own systems.

## Base URL + auth

- Base: `https://YOUR-PORTAL/api/v1`
- Auth: Bearer token. Mint tokens in the portal: **Integration → API tokens** (tenant-admin login required). Guard tokens like passwords; revoke anytime. A token has full v1 access to its tenant only.
- Rate limits: `POST /messages` 60/min; reads unthrottled. `429` when exceeded.
- **"Delivered" = accepted by the provider (HTTP 2xx).** No carrier delivery receipts exist.

## Endpoints

### POST /messages — send SMS/MMS

```bash
curl -X POST https://YOUR-PORTAL/api/v1/messages \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"to": "+15551234567", "from": "15557654321",
       "message": "Hi {name}, your order shipped.", "type": "sms"}'
```

| Field | Required | Notes |
|---|---|---|
| `to` | yes | Destination, 7–15 digits (`+` ok) |
| `from` | yes | One of your account's SMS numbers, 7–15 digits |
| `message` | yes | Max 5000 chars. `$CompanyName` resolves to your company name |
| `type` | no | `sms` (default) or `mms` |
| `data` | no | MMS: base64 media |
| `mime_type` | no | MMS: e.g. `image/png` |
| `size` | no | MMS: byte size, max 1048576 |

Success (`200`):

```json
{ "accepted": true, "session_id": "abc123", "to": "15551234567",
  "from": "15557654321", "provider_status": 200 }
```

Errors: `401` bad token · `403` tenant inactive · `422` validation **or opt-out block**
(`Blocked: this number opted out (do-not-contact).`) · `502` provider error
(`{accepted:false, provider_status, provider_error}`) · `503` provider unavailable.

Opt-outs are enforced on every send — there is no bypass. Replies to your sends land
in the portal inbox (and fire `message.received` below) like any other message.

### GET /scheduled — list scheduled messages

```bash
curl https://YOUR-PORTAL/api/v1/scheduled -H "Authorization: Bearer $TOKEN"
```

Newest 100 (by send time), each with a `counts` summary:
`{queued, delivered, optout, failed, total}`. Same definitions as the portal's
per-message Report drawer.

### GET /scheduled/{id} — full send report

Same object plus `recipients: [{phone, name, status, detail, at}]`, where status is
`queued` | `delivered` | `optout` (filtered: opt-out) | `failed` (provider error in `detail`).

## Outbound webhooks

**Portal → Integration → Outbound webhooks.** Register an `https` URL + event selection
(all 4 = every event). Each event POSTs JSON:

```json
{ "event": "message.received", "at": "2026-09-17T12:00:00Z",
  "domain": "tenantname", "data": { "...": "..." } }
```

| Event | `data` |
|---|---|
| `message.received` | `{session_id, from, dialed, text, type: sms\|mms, at}` |
| `message.sent` | `{session_id, to, from, type, via: "api"}` (v1 sends only) |
| `optout.added` | `{phone, source: manual\|stop-keyword, number}` |
| `optout.removed` | `{phone, keyword}` |
| `webhook.test` | `{ping: true}` (Test button only) |

**Verification (required):** every POST carries
`X-Webhook-Event` and `X-Webhook-Signature: sha256=HMAC_SHA256(signing_secret, raw_body)`.
The secret is generated at creation and shown once — reject unsigned/mismatched bodies.

```python
import hashlib, hmac
sig = request.headers['X-Webhook-Signature']  # "sha256=..."
want = 'sha256=' + hmac.new(SECRET.encode(), request.body, hashlib.sha256).hexdigest()
assert hmac.compare_digest(sig, want)
```

**Delivery:** at-least-once with retries (1m → 5m → 15m → 1h, then recorded failed).
Respond `2xx` quickly; endpoints failing 20 times straight auto-disable (re-enable in
the portal). Recent deliveries (status/error/attempt) are visible per webhook. Targets must be public http(s) hosts — private/internal addresses are rejected at save and at delivery; up to 3 redirects are followed (each hop re-validated).

---

## Operator setup (run once on the server)

1. `composer install` (adds `minishlink/web-push`), `php artisan migrate`
2. Queue worker must run (sends, retries, webhook + push delivery are queued):
   `php artisan queue:work`
3. **CSRF:** token clients can't send CSRF tokens — exclude the v1 API in
   `bootstrap/app.php`: `->validateCsrfTokens(except: ['api/v1/*'])`
   (webhook + portal routes keep their existing handling).
4. **Push (optional):** `php artisan push:vapid-keys` → add the three `VAPID_*` lines
   to `.env`, restart workers. Without keys, Settings shows "server keys not
   configured" and everything else still works. Push + installability need HTTPS
   (localhost is fine for testing).
